library(testthat)
library(dieroller)

test_check("dieroller")
